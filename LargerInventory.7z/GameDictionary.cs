﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ModLoader;

namespace LargerInventory
{
    internal class GameDictionary
    {
        internal static Dictionary<string, Mod> Mods = new();
    }
}
